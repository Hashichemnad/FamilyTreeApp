class AppConstants {
  static const String validateSession = '';
  static const String getMembers = '';
  static const String getMemberTree = '';
  static const String validateLogin = '';
  static const String getNotice = '';
  static const String imageLogo = 'assets/images/logo.png';

}